euro <- c(ATS = 13.7603, BEF = 40.3399, DEM = 1.95583, ESP = 166.386,
	  FIM = 5.94573, FRF = 6.55957, IEP = .787564, ITL = 1936.27,
	  LUF = 40.3399, NLG = 2.20371, PTE = 200.482)

euro.cross <- outer(1/euro, euro)
dimnames(euro.cross) <- list(names(euro),names(euro))
