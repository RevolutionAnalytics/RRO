extern void mkl_set_num_threads(int);
extern int mkl_get_max_threads();
extern void mkl_get_version_string(char *, int);
extern int omp_get_num_threads();
extern void omp_set_num_threads(int);

#include <stdio.h>
#include <ctype.h>
#include <R.h>
#include <omp.h>

void setThreads (int k) {
        mkl_set_num_threads(k);
        //omp_set_num_threads(k);
}

void getThreads (int *k) {
        k[0] = mkl_get_max_threads();
}

void getVersionString ()
{
        int len=198;
        char buf[202];  /* Win32 seems to need a buffer bigger than speced len */
        mkl_get_version_string(buf, len);
        Rprintf("%s", buf);
}
